# Hospital Management System

## 🏥 Description
A basic hospital management system using HTML/CSS for the front end and Python Flask for the backend.

## 📋 Features
- Home page with login options for Doctor and Patient
- Displays dummy patient records
- Flask-based routing

## 🔧 Technologies Used
- Front-End: HTML, CSS
- Back-End: Python Flask

## ⚙️ How to Run the Project
1. Make sure Python is installed
2. Install Flask:
   ```
   pip install flask
   ```
3. Run the server:
   ```
   python app.py
   ```
4. Open your browser and go to:
   ```
   http://127.0.0.1:5000/
   ```

## ✅ Pages
- `/` → Home Page
- `/patients` → Patient Records
- `/doctors` → Doctor Dashboard