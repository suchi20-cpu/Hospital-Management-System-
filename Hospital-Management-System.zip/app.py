from flask import Flask

app = Flask(__name__)

# Dummy patient data
patients = [
    {"id": 1, "name": "John Doe", "age": 30, "condition": "Flu"},
    {"id": 2, "name": "Jane Smith", "age": 45, "condition": "Diabetes"},
    {"id": 3, "name": "Bob Johnson", "age": 60, "condition": "Heart Disease"}
]

@app.route('/')
def home():
    return open('index.html').read()

@app.route('/patients')
def show_patients():
    html = "<h2>Patient Records</h2><table border='1' style='margin:auto'><tr><th>ID</th><th>Name</th><th>Age</th><th>Condition</th></tr>"
    for p in patients:
        html += f"<tr><td>{p['id']}</td><td>{p['name']}</td><td>{p['age']}</td><td>{p['condition']}</td></tr>"
    html += "</table>"
    return html

@app.route('/doctors')
def doctors():
    return "<h2>Doctor Dashboard</h2><p>Manage your patients here.</p>"

if __name__ == '__main__':
    app.run(debug=True)